# Expense Tracker / Personal Finance App (MERN)

Full-stack expense tracker with user auth, CRUD for income/expenses, categories, and charts.

## Tech Stack

- **Frontend:** React (Vite), React Router, Recharts
- **Backend:** Node.js, Express
- **Database:** MongoDB (Mongoose)
- **Auth:** JWT

## Features

- **User authentication** – Register / login; data is per user
- **Add, edit, delete** income and expenses
- **Categories** – Income (Salary, Freelance, etc.) and expense (Food, Transport, Rent, etc.)
- **Monthly / weekly summary** – Income, expense, balance for current week or month
- **Charts** – Bar chart (income vs expense by month), pie chart (expenses by category)

## Quick Start

### 1. MongoDB

Have MongoDB running locally, or use [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and set `MONGODB_URI`.

### 2. Backend

```bash
cd server
cp .env.example .env
# Edit .env: set MONGODB_URI and JWT_SECRET
npm install
npm run dev
```

API runs at `http://localhost:5000`.

### 3. Frontend

```bash
cd client
npm install
npm run dev
```

App runs at `http://localhost:3000` and is proxied to the API via Vite.

### 4. Environment

**Server (`.env`):**

- `PORT` – default 5000
- `MONGODB_URI` – MongoDB connection string
- `JWT_SECRET` – secret for signing tokens

**Client (optional):**

- `VITE_API_URL` – e.g. `https://your-api.onrender.com/api` when deploying frontend separately

## API Overview

- `POST /api/auth/register` – Register (email, password, name)
- `POST /api/auth/login` – Login (email, password)
- `GET /api/auth/me` – Current user (Bearer token)
- `GET/POST /api/transactions` – List, create (type, amount, category, description, date)
- `GET/PUT/DELETE /api/transactions/:id` – Get, update, delete
- `GET /api/summary/overview?period=week|month` – Income, expense, balance
- `GET /api/summary/by-category?period=week|month&type=expense` – Totals by category
- `GET /api/summary/monthly-trend?months=6` – Monthly income/expense for charts

## Deployment

- **Frontend:** Deploy `client` to **Vercel**. Set `VITE_API_URL` to your backend URL (e.g. `https://expense-tracker-api.onrender.com/api`).
- **Backend:** Deploy `server` to **Render** (or similar). Add `MONGODB_URI` (e.g. Atlas) and `JWT_SECRET`. In Render dashboard, use “Web Service”, build `npm install`, start `npm start`.
- **CORS:** Backend uses `cors({ origin: true })`; for production you can restrict `origin` to your Vercel URL.

## License

MIT
