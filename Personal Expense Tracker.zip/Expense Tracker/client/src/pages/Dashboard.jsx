import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';
import TransactionForm from '../components/TransactionForm';
import TransactionList from '../components/TransactionList';

const PERIODS = ['week', 'month'];
const CATEGORY_COLORS = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16'];

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [period, setPeriod] = useState('month');
  const [overview, setOverview] = useState({ income: 0, expense: 0, balance: 0 });
  const [byCategory, setByCategory] = useState([]);
  const [monthlyTrend, setMonthlyTrend] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const fetchData = useCallback(async () => {
    try {
      const [overviewRes, categoryRes, trendRes, listRes] = await Promise.all([
        api.get(`/summary/overview?period=${period}`),
        api.get(`/summary/by-category?period=${period}&type=expense`),
        api.get('/summary/monthly-trend?months=6'),
        api.get('/transactions?limit=50'),
      ]);
      setOverview(overviewRes);
      setByCategory(categoryRes);
      setMonthlyTrend(trendRes);
      setTransactions(listRes);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [period]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAdd = () => {
    setEditingId(null);
    setShowForm(true);
  };

  const handleEdit = (id) => {
    setEditingId(id);
    setShowForm(true);
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingId(null);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this transaction?')) return;
    try {
      await api.delete(`/transactions/${id}`);
      fetchData();
    } catch (err) {
      alert(err.message || 'Delete failed');
    }
  };

  const pieData = byCategory.map((d, i) => ({
    name: d.category,
    value: d.total,
    color: CATEGORY_COLORS[i % CATEGORY_COLORS.length],
  }));

  if (loading) return <div className="loading">Loading...</div>;

  return (
    <div className="app">
      <header className="header">
        <h1>Expense Tracker</h1>
        <nav className="nav">
          <span className="user-badge">{user?.name}</span>
          <button type="button" className="btn btn-ghost" onClick={logout}>
            Logout
          </button>
        </nav>
      </header>

      <div className="period-tabs">
        {PERIODS.map((p) => (
          <button
            key={p}
            type="button"
            className={period === p ? 'active' : ''}
            onClick={() => setPeriod(p)}
          >
            {p === 'week' ? 'This week' : 'This month'}
          </button>
        ))}
      </div>

      <div className="summary-grid">
        <div className="summary-card income">
          <h3>Income</h3>
          <div className="value">${Number(overview.income).toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="summary-card expense">
          <h3>Expenses</h3>
          <div className="value">${Number(overview.expense).toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="summary-card balance">
          <h3>Balance</h3>
          <div className="value">${Number(overview.balance).toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
        </div>
      </div>

      <div className="chart-section">
        <h2>Income vs Expenses (last 6 months)</h2>
        <div style={{ height: 260 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyTrend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${v}`} />
              <Tooltip formatter={(v) => [`$${Number(v).toFixed(2)}`, '']} labelFormatter={(l) => `Month: ${l}`} />
              <Bar dataKey="income" fill="#22c55e" name="Income" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expense" fill="#ef4444" name="Expense" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {pieData.length > 0 && (
        <div className="chart-section">
          <h2>Expenses by category ({period})</h2>
          <div style={{ height: 280 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  nameKey="name"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(v) => `$${Number(v).toFixed(2)}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="section-header">
        <h2>Transactions</h2>
        <button type="button" className="btn btn-primary" onClick={handleAdd}>
          Add transaction
        </button>
      </div>

      <TransactionList
        transactions={transactions}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      {showForm && (
        <TransactionForm
          transactionId={editingId}
          onClose={handleFormClose}
          onSaved={handleFormClose}
        />
      )}
    </div>
  );
}
