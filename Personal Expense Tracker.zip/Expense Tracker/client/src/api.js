const API_BASE = import.meta.env.VITE_API_URL || '/api';

function getHeaders() {
  const token = localStorage.getItem('token');
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
}

export const api = {
  get: (path) => fetch(API_BASE + path, { headers: getHeaders() }).then((r) => {
    if (!r.ok) return r.json().then((d) => Promise.reject(d));
    return r.json();
  }),
  post: (path, body) =>
    fetch(API_BASE + path, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(body),
    }).then((r) => {
      const data = r.json();
      if (!r.ok) return data.then((d) => Promise.reject(d));
      return data;
    }),
  put: (path, body) =>
    fetch(API_BASE + path, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(body),
    }).then((r) => {
      const data = r.json();
      if (!r.ok) return data.then((d) => Promise.reject(d));
      return data;
    }),
  delete: (path) =>
    fetch(API_BASE + path, { method: 'DELETE', headers: getHeaders() }).then((r) => {
      if (r.status === 204 || (r.ok && r.headers.get('content-length') === '0')) return {};
      const data = r.json();
      if (!r.ok) return data.then((d) => Promise.reject(d));
      return data;
    }),
};
