import React, { useState, useEffect } from 'react';
import { api } from '../api';

const TYPES = ['income', 'expense'];
const COMMON_CATEGORIES = {
  income: ['Salary', 'Freelance', 'Investment', 'Gift', 'Other'],
  expense: ['Food', 'Transport', 'Rent', 'Utilities', 'Shopping', 'Health', 'Entertainment', 'Other'],
};

export default function TransactionForm({ transactionId, onClose, onSaved }) {
  const [type, setType] = useState('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(COMMON_CATEGORIES.expense[0]);
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingTransaction, setLoadingTransaction] = useState(!!transactionId);

  useEffect(() => {
    if (!transactionId) return;
    api.get(`/transactions/${transactionId}`)
      .then((t) => {
        const cats = COMMON_CATEGORIES[t.type] || [];
        const validCategory = cats.includes(t.category) ? t.category : (cats[0] || 'Other');
        setType(t.type);
        setAmount(String(t.amount));
        setCategory(validCategory);
        setDescription(t.description || '');
        setDate(t.date ? new Date(t.date).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10));
      })
      .catch(() => setError('Failed to load transaction'))
      .finally(() => setLoadingTransaction(false));
  }, [transactionId]);

  useEffect(() => {
    if (!category || COMMON_CATEGORIES[type].includes(category)) return;
    setCategory(COMMON_CATEGORIES[type][0] || '');
  }, [type]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const payload = {
        type,
        amount: parseFloat(amount),
        category: category || (type === 'income' ? 'Other' : 'Other'),
        description: description.trim(),
        date: new Date(date).toISOString(),
      };
      if (transactionId) {
        await api.put(`/transactions/${transactionId}`, payload);
      } else {
        await api.post('/transactions', payload);
      }
      onSaved();
    } catch (err) {
      setError(err.message || 'Save failed');
    } finally {
      setLoading(false);
    }
  };

  if (loadingTransaction) return <div className="loading">Loading...</div>;

  const categories = COMMON_CATEGORIES[type];

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>{transactionId ? 'Edit transaction' : 'Add transaction'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Type</label>
            <select value={type} onChange={(e) => setType(e.target.value)}>
              {TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Amount</label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              placeholder="0.00"
            />
          </div>
          <div className="form-group">
            <label>Category</label>
            <select value={category} onChange={(e) => setCategory(e.target.value)}>
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Description (optional)</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Note"
            />
          </div>
          <div className="form-group">
            <label>Date</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          </div>
          {error && <p className="error-msg">{error}</p>}
          <div className="form-actions">
            <button type="button" className="btn btn-ghost" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Saving...' : (transactionId ? 'Update' : 'Add')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
