import React from 'react';

function formatDate(d) {
  return new Date(d).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export default function TransactionList({ transactions, onEdit, onDelete }) {
  if (!transactions?.length) {
    return <div className="empty-state">No transactions yet. Add one to get started.</div>;
  }

  return (
    <div className="transaction-list">
      {transactions.map((t) => (
        <div key={t._id} className="transaction-item">
          <div className="left">
            <span className="category">{t.category}</span>
            <span className="meta">
              {t.description ? `${t.description} · ` : ''}{formatDate(t.date)}
            </span>
          </div>
          <span className={`amount ${t.type}`}>
            {t.type === 'income' ? '+' : '-'}${Number(t.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </span>
          <div className="actions">
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => onEdit(t._id)}>
              Edit
            </button>
            <button type="button" className="btn btn-danger btn-sm" onClick={() => onDelete(t._id)}>
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
