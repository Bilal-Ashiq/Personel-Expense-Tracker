import express from 'express';
import Transaction from '../models/Transaction.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();
router.use(protect);

function getStartOfWeek(d) {
  const date = new Date(d);
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  date.setDate(diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

function getStartOfMonth(d) {
  const date = new Date(d);
  date.setDate(1);
  date.setHours(0, 0, 0, 0);
  return date;
}

router.get('/overview', async (req, res) => {
  try {
    const { period = 'month' } = req.query; // 'week' | 'month'
    const now = new Date();
    const start = period === 'week' ? getStartOfWeek(now) : getStartOfMonth(now);

    const match = { user: req.user._id, date: { $gte: start } };
    const docs = await Transaction.aggregate([
      { $match: match },
      { $group: { _id: '$type', total: { $sum: '$amount' } } },
    ]);

    let income = 0, expense = 0;
    docs.forEach((d) => {
      if (d._id === 'income') income = d.total;
      else expense = d.total;
    });

    res.json({
      period,
      income,
      expense,
      balance: income - expense,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/by-category', async (req, res) => {
  try {
    const { period = 'month', type = 'expense' } = req.query;
    const now = new Date();
    const start = period === 'week' ? getStartOfWeek(now) : getStartOfMonth(now);

    const data = await Transaction.aggregate([
      { $match: { user: req.user._id, type, date: { $gte: start } } },
      { $group: { _id: '$category', total: { $sum: '$amount' } } },
      { $sort: { total: -1 } },
    ]);

    res.json(data.map((d) => ({ category: d._id, total: d.total })));
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/monthly-trend', async (req, res) => {
  try {
    const months = Number(req.query.months) || 6;
    const end = new Date();
    const start = new Date(end.getFullYear(), end.getMonth() - months, 1);

    const data = await Transaction.aggregate([
      { $match: { user: req.user._id, date: { $gte: start, $lte: end } } },
      {
        $group: {
          _id: { year: { $year: '$date' }, month: { $month: '$date' }, type: '$type' },
          total: { $sum: '$amount' },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ]);

    const byMonth = {};
    data.forEach((d) => {
      const key = `${d._id.year}-${String(d._id.month).padStart(2, '0')}`;
      if (!byMonth[key]) byMonth[key] = { month: key, income: 0, expense: 0 };
      byMonth[key][d._id.type] = d.total;
    });

    const result = Object.values(byMonth).sort((a, b) => a.month.localeCompare(b.month));
    res.json(result);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
